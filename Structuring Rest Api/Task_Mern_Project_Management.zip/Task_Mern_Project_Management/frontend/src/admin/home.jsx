import React from 'react'
import Header from './Header'

function home() {
  
  return (
    <>
    <Header/>
      <div className='w-full h-screen flex flex-col items-center justify-center bg-gray-100'>
        <h1 className='text-4xl font-bold mb-4'>Welcome To Project Tracker App</h1>
       
        
    </div>
    </>
  
  )
}

export default home