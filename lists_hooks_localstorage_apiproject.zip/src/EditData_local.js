import React, { useEffect, useState } from 'react'
// import { student } from './Objarray'
import { Link, useNavigate, useParams } from 'react-router-dom'

function EditData_local() {
    const {id} = useParams()
    let students = JSON.parse(localStorage.getItem("x")) || [];
    let editstudent = students.find((student) => student.id == id);

    const [name, setName] = useState(editstudent.name)
    const [email, setEmail] = useState(editstudent.email)
    const navigate = useNavigate()
    // console.log(name);
    const handleData = () => {
        // e.preventDefault();
        const updatedStudents = students.map(student => 
            student.id == id ? { ...student, name, email } : student
        );

        // Save updated data to localStorage
        localStorage.setItem("x", JSON.stringify(updatedStudents));

        // localStorage.setItem("x", JSON.stringify(students));

        navigate('/homelocal');
    };
    return (
        <div>
            <div className='container'>
                <div className='row justify-content-center'>
                    <div className='col-lg-6'>
                        <h1>Edit New Student</h1>
                        <div className='card text-start shadow-lg p-3'>
                            <form >
                                <div className='mb-3'>
                                    <label>
                                        Name
                                    </label>
                                    <input
                                        type='text'
                                        className='form-control'
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                    >

                                    </input>
                                </div>
                                <div className='mb-3'>
                                    <label>
                                        Email
                                    </label>
                                    <input
                                        type='text'
                                        className='form-control'
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    >

                                    </input>
                                </div>
                                <div className='d-flex justify-content-between'>
                                    <button type='button' onClick={handleData}  className='btn btn-success fw-semibold mx-2 mt-3'>Submit</button>
                                    <Link to={'/'} className='btn btn-danger fw-semibold mx-2 mt-3'>cancle</Link>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default EditData_local