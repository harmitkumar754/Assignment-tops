import React, { useEffect, useState } from 'react'
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement, reset } from "./Store";

function Hooks() {
    const [No, setNo] = useState(0);
    const [data, setData] = useState([]);
    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/users')
        .then((response)=>response.json())
        .then((data)=>setData(data))
    },[])

  
      const count = useSelector((state) => state.counter.value);
      const dispatch = useDispatch();
    
  return (
    <div>
    <h1>Hooks</h1>
    <hr/>
    <h2>Task 1: </h2><h3>Create a functional component with a counter using the useState()hook. Include
    buttons to increment and decrement the counter.</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
       <button className="btn btn-warning me-2 fs-2" onClick={()=>{setNo(No-1)}}>-</button>
      <h1 className='d-inline '> {No}</h1>
       <button className="btn btn-warning ms-2 fs-2" onClick={()=>{setNo(No+1)}}>+</button>
       

    </div>

    <hr/>
    <h2>Task 2: </h2><h3> Use the useEffect()hook to fetch and display data from an API when the
    component mounts<br/>"https://jsonplaceholder.typicode.com/users" this api get name</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
    <ul  className='d-inline-block'>
            {data.map((value, index) => (
                <li key={index}>{value.name}</li>
            ))}
        </ul>

    </div>

    <hr/>
    <h2>Task 3: </h2><h3> Create react app with use of useSelector & useDispatch. </h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
    
      
    <div style={{ textAlign: "center", padding: "20px", border: "1px solid #ccc", width: "300px", margin: "50px auto" }}>
      <h2>Redux Counter</h2>
      <p style={{ fontSize: "24px", fontWeight: "bold" }}>{count}</p>
      <div>
        <button onClick={() => dispatch(increment())} style={{ margin: "5px", padding: "10px", background: "green", color: "white", border: "none", cursor: "pointer" }}>Increment</button>
        <button onClick={() => dispatch(decrement())} style={{ margin: "5px", padding: "10px", background: "red", color: "white", border: "none", cursor: "pointer" }}>Decrement</button>
        <button onClick={() => dispatch(reset())} style={{ margin: "5px", padding: "10px", background: "gray", color: "white", border: "none", cursor: "pointer" }}>Reset</button>
      </div>
    </div>
         
       

    </div>

    <hr/>
    <h2>Task 4: </h2><h3>Create react app to avoid re-renders in react application by useRef ?
    </h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
    <h1 className='bg-warning'>This topic remains to be explained. I will edit the file after explaining. </h1>  

    </div>

    </div>
  )
}

export default Hooks