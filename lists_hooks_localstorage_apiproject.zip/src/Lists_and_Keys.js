import React from 'react'

function Lists_and_Keys() {
    const fruits = ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry'];
    const users = [{id: 1, name: 'Harmit'}, {id: 2, name: 'om'}, {id: 3, name: 'manan'}, {id: 4, name: 'miraj'}, {id: 5, name: 'jenil'}];
  return (
    <div><h1>Lists_and_Keys</h1>
    <hr/>
    <h2>Task 1: </h2><h3>Create a React component that renders a list of items (e.g., a list of fruit names). 
    Usethe map () function to render each item in the list</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
        <ul  className='d-inline-block'>
            {fruits.map((fruit, index) => (
                <li key={index}>{fruit}</li>
            ))}
        </ul>

    </div>

    <hr/>
    <h2>Task 2: </h2><h3>Create a list of users where each user has a unique id. Render the user list 
    usingReact and assign a unique keyto each user</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
        <ul className='d-inline-block'>
            {users.map((v) => (
                <li key={v.id}>{v.name}</li>
            ))}
        </ul>

    </div>
    </div>
  )
}

export default Lists_and_Keys