import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AddStudent_local() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const navigate = useNavigate();

    const handleData = (e) => {
        e.preventDefault();

        
        let students = JSON.parse(localStorage.getItem("x")) || [];

        const newStudent = {
            id: students.length > 0 ? students[students.length - 1].id + 1 : 1,
            // id:students.length+1,
            name: name,
            email: email
        };

        students.push(newStudent);

        localStorage.setItem("x", JSON.stringify(students));

        navigate('/homelocal');
    };

    return (
        <div className='container'>
            <div className='row justify-content-center'>
                <div className='col-lg-6'>
                    <h1>Add New Student</h1>
                    <div className='card text-start shadow-lg p-3'>
                        <form onSubmit={handleData}>
                            <div className='mb-3'>
                                <label>Name</label>
                                <input
                                    type='text'
                                    className='form-control'
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    required
                                />
                            </div>
                            <div className='mb-3'>
                                <label>Email</label>
                                <input
                                    type='text'
                                    className='form-control'
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                            <div className='d-flex justify-content-between'>
                                <button type='submit' className='btn btn-success fw-semibold mx-2 mt-3'>
                                    Submit
                                </button>
                                <button
                                    type='button'
                                    className='btn btn-danger fw-semibold mx-2 mt-3'
                                    onClick={() => navigate('/')}
                                >
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
