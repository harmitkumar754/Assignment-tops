import React from 'react'
import Api_contex_theme from './Api_contex_theme'

function ApiProject() {
  return (
    <div><h1>Api Project/Context API
 </h1>
    <hr/>
    <h2>Task 1: </h2><h3>Create a simple theme toggle (light/dark mode) using the Context API. The
    themestate should be shared across multiple components.</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
   <Api_contex_theme/> 

    </div>

    <hr/>

    <h2>Task 2: </h2><h3>Use the Context API to create a global user authentication system. If the user
    islogged in, display a welcome message; otherwise, prompt them to log in.</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
    <h1 className='bg-warning'>This topic remains to be explained. I will edit the file after explaining. </h1> 

    </div>

    </div>
  )
}

export default ApiProject