import React from 'react'
import Home_local from './Home_local'


function Localstorage() {
  return (
    <div><h1>Local Storage  </h1>
    <hr/>
    <h2>Task 1: </h2><h3>Crud</h3>
    <hr/>
    <div className='container text-start bg-light p-5 text-center'>
   <Home_local/>

    </div>
    </div>
  )
}

export default Localstorage