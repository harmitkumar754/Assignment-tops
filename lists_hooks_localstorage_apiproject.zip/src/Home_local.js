import React, { useState } from 'react'
// import { student } from './Objarray'
import {Link} from 'react-router-dom'
export default function Home_local() {
    let students = JSON.parse(localStorage.getItem("x")) || [];
    const [student1,SetStudent] = useState(students)
    const removedata = (id)=>{
        const updatedStudents = student1.filter((student) => student.id !== id);
        SetStudent(updatedStudents);
        localStorage.setItem("x", JSON.stringify(updatedStudents));
        alert("Are You Sure You Want To Delete This Student")
    }
    return (
        <div>
            <div className='container'>
                <div className='row justify-content-center'>
                    <div className='col-lg-6'>
                        <h1>Home page</h1>
                        <table className='table'>
                            <thead className='bg-dark text-white'>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                {
                                     student1 && student1.map((v) => (
                                        <tr key={v.id}>
                                            <td>{v.id}</td>
                                            <td>{v.name}</td>
                                            <td>{v.email}</td>
                                            <td>
                                                <button onClick={()=>removedata(v.id)} className='fw-semibold btn btn-danger mx-2'>Delete</button>
                                                <Link to={`/edit/${v.id}`} className='fw-semibold btn btn-warning mx-2'>Edit</Link>

                                            </td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                        <Link to={'/add'} className='btn btn-info fw-semibold'>Add New Student</Link>

                    </div>
                </div>
            </div>

        </div>
    )
}
