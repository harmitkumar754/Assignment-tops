// import logo from './logo.svg';
// import './App.css';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import '../node_modules/bootstrap/dist/js/bootstrap.js';
import Conditional_Rendering from './Conditional_Rendering.js';
import Home from './Home.js';
import Lists_and_Keys from './Lists_and_Keys.js';
import Hooks from './Hooks.js';
import Localstorage from './Localstorage.js';
import ApiProject from './ApiProject.js';
import Store from './Store.js';
import { Provider } from "react-redux";
import AddStudent_local from './AddStudent_local.js';
import EditData_local from './EditData_local.js';
import Home_local from './Home_local.js';

function App() {
  return (
    <div className="App">
      <Provider store={Store}>
       <BrowserRouter>
     
     <nav className="navbar navbar-expand-lg navbar-light bg-light">
       <div className="container-fluid">
         
         <div className="collapse navbar-collapse" id="navbarNav">
           <ul className="navbar-nav">
             <li className="nav-item">
               <Link className=" btn btn-info me-2" to="/">Home</Link>
             </li>
             <li className="nav-item">
               <Link className="btn btn-info me-2" to="/Conditional_Rendering">Conditional_Rendering</Link>
             </li>
             <li className="nav-item">
               <Link className="btn btn-info me-2" to="/Lists_and_Keys">Lists_and_Keys</Link>
             </li>
             <li className="nav-item">
               <Link className="btn btn-info me-2" to="/Hooks">Hooks</Link>
             </li>
             <li className="nav-item">
               <Link className="btn btn-info me-2" to="/Localstorage">Localstorage</Link>
             </li>
             <li className="nav-item">
               <Link className="btn btn-info me-2" to="/ApiProject">Api Project</Link>
             </li>
            
           </ul>
         </div>
       </div>
       </nav>
    <Routes>
       
         <Route path="/" element={<Home/>} />
         <Route path="/Conditional_Rendering" element={<Conditional_Rendering/>}/>
         <Route path="/Lists_and_Keys" element={<Lists_and_Keys/>}/>
         <Route path="/Hooks" element={<Hooks/>}/>
         <Route path="/Localstorage" element={<Localstorage/>}/>
         <Route path="/ApiProject" element={<ApiProject/>}/>

         <Route path="/homelocal" element={<Home_local/>}/>
         <Route path="/Add" element={<AddStudent_local/>}/>
         <Route path="/edit/:id" element={<EditData_local/>}/>
       
     
    </Routes>
    </BrowserRouter>
    </Provider>
    </div>
  );
}

export default App;
