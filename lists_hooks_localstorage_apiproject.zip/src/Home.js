import React from 'react'

function Home() {
  return (
    <div>
        <h1>Assignment</h1>
        <ul>
            <li>Conditional Rendering</li>
            <li>Lists </li>
            <li> Hooks </li>
            <li>Localstorage </li>
            <li> Api Project</li>
        </ul>
    </div>
  )
}

export default Home