import React, { createContext, useContext, useState } from "react";

// Create Theme Context
const ThemeContext = createContext();

// Theme Provider Component
const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div className={theme === "light" ? "bg-white text-black" : "bg-black text-white"}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
};

// Custom Hook to use Theme
const useTheme = () => useContext(ThemeContext);

// ThemeToggle Component
const ThemeToggle = () => {
  const { toggleTheme } = useTheme();
  return <button onClick={toggleTheme} className="px-4 py-2 bg-gray-800  rounded">Toggle Theme</button>;
};

// Sample Component that uses the theme
const Home = () => {
  const { theme } = useTheme();
  return <h1 className="text-center text-xl p-4">Current Theme: {theme}</h1>;
};

// Main App Component
const Api_contex_theme = () => {
  return (
    <ThemeProvider>
      <div className="min-h-screen flex flex-col items-center justify-center">
        <Home />
        <ThemeToggle />
      </div>
    </ThemeProvider>
  );
};

export default Api_contex_theme;
