import React, { useState } from 'react'

function Conditional_Rendering() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const handleLogin = () => setIsLoggedIn(true);
  const handleLogout = () => setIsLoggedIn(false);

  const [age, setAge] = useState(0);
  return (
    <div>
    <h1>Conditional_Rendering</h1>
    <hr/>
    <h2> Task 1:</h2><h3> Create a component that conditionally displays a login or logout button based 
    onthe user's login status</h3>
    <hr/>
   <div className='container text-center bg-light p-5'>
   <h1 className=" mb-4">
            {isLoggedIn ? "Welcome back!" : "Please log in."}
          </h1>
          <button onClick={isLoggedIn ? handleLogout : handleLogin}  className="">
            {isLoggedIn ? "Logout" : "Login"}
          </button>
   </div>
    <hr/>
   <h2> Task 2:</h2><h3> Implement a component that displays a message like "You are eligible to vote" if 
   theuser is over 18, otherwise display "You are not eligible to vote."</h3>
    <hr/>
    <div className='container text-center bg-light p-5'>
        <input type='number' placeholder='Enter your age' value={age} onChange={(e)=>setAge(e.target.value)}/>
    <h1 className=" mb-4">
            {age>=18 ? "You are eligible to vote" : "You are not eligible to vote."}
          </h1>
  
         
   </div>
</div>
  )
}

export default Conditional_Rendering